a = 15.0
b = 10.0
c = 25.0
puts ("Vvedite 3 chisla: #{a} #{b} #{c}")
geom = (a * b * c) ** (1.0/3.0)
puts ("#{geom}")