ch = int(input('Введите число: '))
c = ch // 10 % 10
b = ch // 100 %10
sum = b + c
print (sum)