x = int(input('Введите число: '))
y = int(input('Введите число: '))
x, y = y, x
print (x)
print (y)