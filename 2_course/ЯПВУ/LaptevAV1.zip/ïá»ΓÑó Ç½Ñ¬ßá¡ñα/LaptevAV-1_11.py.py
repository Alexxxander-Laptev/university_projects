x1 = float(input('Введите координату: '))
y1 = float(input('Введите координату: '))
x2 = float(input('Введите координату: '))
y2 = float(input('Введите координату: '))
ras = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
print (ras)