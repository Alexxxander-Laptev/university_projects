package main
import "fmt"

func main() {
    var a = 2.0
    var b = 5.0
    var c = 9.0
    fmt.Println ((a + b + c) / 3)
}