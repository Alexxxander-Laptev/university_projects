x1 = float(input('Введите координату: '))
y1 = float(input('Введите координату: '))
x2 = float(input('Введите координату: '))
y2 = float(input('Введите координату: '))
x3 = float(input('Введите координату: '))
y3 = float(input('Введите координату: '))
s = abs ((x1 - x3) * (y2 - y3) - ((y1 - y3) * (x2 - x3))) / 2
print (s)