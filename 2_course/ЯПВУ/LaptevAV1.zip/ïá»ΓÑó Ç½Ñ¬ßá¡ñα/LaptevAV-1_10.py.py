x = int(input('Введите число: '))
y = int(input('Введите число: '))
per = x
x = y
y = per
print (x, y)