# encoding utf-8
puts ('Vvedite 2 chisla: ')
x = gets.to_i
y = gets.to_i
per = x
x = y
y = per
puts ("#{x} #{y}")