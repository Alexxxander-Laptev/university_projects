a = 2
b = 5
c = 9
print ("Vvedite 3 chisla: ", a, b, c)
ar = (a + b + c) / 3
print (ar)