ch = 156
puts ("Vvedite chislo: #{ch}")
c = ch % 10
b = ch / 10 % 10
a = ch / 100
puts ("#{a} #{b} #{c}")