# encoding utf-8
puts ('Vvedite 2 chisla: ')
x = gets.to_i
y = gets.to_i
x, y = y, x
puts ("#{x} #{y}")