a = 15
b = 10
c = 25
print ("Vvedite 3 chisla: ", a, b, c)
geom = (a * b * c) ** (1/3)
print (geom)