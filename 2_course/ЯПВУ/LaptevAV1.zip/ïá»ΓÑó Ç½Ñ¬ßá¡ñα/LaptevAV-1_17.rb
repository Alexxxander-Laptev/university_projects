k = 0.577
puts ("Vvedite veshestvennoe chislo: #{k}")
al = Math.atan(k) * 180 / Math::PI
print ("#{al}")