ch = int(input('Введите число: '))
b = ch % 10
a = ch // 1000
sum = a + b
print (sum)