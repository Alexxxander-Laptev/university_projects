a = 2.0
b = 5.0
c = 9.0
puts ("Vvedite 3 chisla: #{a} #{b} #{c}")
ar = (a + b + c) / 3
puts ("#{ar}")